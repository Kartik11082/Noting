from django.apps import AppConfig


class NotingappConfig(AppConfig):
    name = 'notingApp'
