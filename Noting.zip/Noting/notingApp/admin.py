from django.contrib import admin
from .models import NotingModel

# Register your models here.
admin.site.register(NotingModel)